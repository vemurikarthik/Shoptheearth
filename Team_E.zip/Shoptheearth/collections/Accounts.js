Accounts.config({
	forbidClientAccountCreation : false
});