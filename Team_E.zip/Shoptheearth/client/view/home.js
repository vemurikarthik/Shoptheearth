Template.home.helpers({ 




	url:Meteor.user().services.twitter.profile_image_url



});